---
name: I used sisl in a publication
about: Add the publication to the documentation page of sisl

---
<!--
Fill in these blanks and it will be added to the documentation page
-->

- [ ] Author list
- [ ] Publication title
- [ ] Journal information
- [ ] DOI

<!--
An example input in the documentation looks like:

#. N. Papior, N. Lorente, T. Frederiksen, A. Garcia and M. Brandbyge,
   *Improvements on non-equilibrium and transport Green function techniques: The next-generation TranSiesta*,
   Computer Physics Communications **212**, `8 (2017) <https://doi.org/10.1016/j.cpc.2016.09.022>`_


Thanks for using sisl and publicising the article here!
-->
