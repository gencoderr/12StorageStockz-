---
name: Issue
about: Let us know if something is bothering you

---

**Describe the issue**

**Version details**
Run the below code and add to issue (if an issue is relevant for the issue):
```python
import sisl._debug_info as sd
sd.print_debug_info()
```
