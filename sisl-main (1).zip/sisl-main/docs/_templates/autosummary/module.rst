.. automodule:: {{ fullname }}
   :no-members:
   :no-undoc-members:
   :no-inherited-members:
