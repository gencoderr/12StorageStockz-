.. .. _utilities:

************************
Utilities (`sisl.utils`)
************************

.. module:: sisl.utils

Various helper classes and functions that make using `sisl` easier.


.. toctree::
   :maxdepth: 2

   utilities.shape
   utilities.misc

   parse_rotation
