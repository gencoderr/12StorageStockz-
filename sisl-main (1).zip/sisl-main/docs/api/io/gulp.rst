.. _io.gulp:

GULP
====

.. module:: sisl.io.gulp

.. autosummary::
   :toctree: generated/

   gotSileGULP - the output from GULP
   fcSileGULP - force constant output from GULP
