.. _io.generic:

Generic files
=============

.. currentmodule:: sisl.io

.. autosummary::
   :toctree: generated/

   tableSile
   xyzSile
   pdbSile
   cubeSile
   moldenSile
   xsfSile
