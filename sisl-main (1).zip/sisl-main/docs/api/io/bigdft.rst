.. _io.bigdft:

.. module:: sisl.io.bigdft

BigDFT
======

.. autosummary::
   :toctree: generated/

   asciiSileBigDFT
