.. _io.fhiaims:

.. module:: sisl.io.fhiaims

FHIaims
=======

.. autosummary::
   :toctree: generated/

   inSileFHIaims
