:orphan:

.. currentmodule:: sisl.physics.electron

.. autosummary::
   :toctree: generated/

   _electron_State
