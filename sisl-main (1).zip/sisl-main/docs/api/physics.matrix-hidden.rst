:orphan:

.. currentmodule:: sisl.physics

.. autosummary::
   :toctree: generated/

   densitymatrix._densitymatrix
