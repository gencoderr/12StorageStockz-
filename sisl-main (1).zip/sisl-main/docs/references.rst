.. _references:

Bibliography
============

.. create the bibliography will all references.
   We may still use local footnote bib's for clarity.

.. bibliography:: references.bib
