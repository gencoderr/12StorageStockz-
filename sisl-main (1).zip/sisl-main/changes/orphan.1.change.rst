Enabled simpler `rotation` argument to `Geometry.rotate`

This makes rotation arguments more versatile, and also
easier to combine.

One can now do lists of rotations that then gets parsed
directly.
