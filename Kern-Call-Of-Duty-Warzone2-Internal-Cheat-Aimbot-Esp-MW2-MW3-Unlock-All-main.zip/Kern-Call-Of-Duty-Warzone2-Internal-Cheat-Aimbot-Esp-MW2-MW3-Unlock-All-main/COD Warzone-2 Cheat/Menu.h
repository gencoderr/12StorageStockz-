#pragma once
#include <Windows.h>
#include "stdafx.h"


namespace g_menu
{
	void menu();
	void FOVCircle();
}