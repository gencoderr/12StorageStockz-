#include "globals.h"
#include "sdk.h"

namespace globals
{

}

namespace color
{
	ImColor Color{ 1.f,1.f,1.f,1.f };
}