#pragma once
#include "stdafx.h"
#include "sdk.h"

namespace globals
{

}


namespace color
{
	extern ImColor Color;
}