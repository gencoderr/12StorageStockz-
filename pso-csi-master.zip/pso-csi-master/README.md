# Pure Service Orchestrator (PSO) CSI Driver

<img src="./docs/images/pso_logo.png" width="250">

## !!Stop here!! - PSO is EOL by July 31 and End of Support by Oct 31, 2022.
* New customers should switch to our new cloud native soution [Portworx](https://portworx.com/) for your FlashArray/FlashBlade storages. 
* Current customers can use the self-sevice [PSO2PX Tool](https://github.com/purestorage/pso-csi/tree/master/pso2px) to migrate PSO Volumes to Portworx.
* Please contact [support@purestorage.com](mailto:support@purestorage.com) or your sales manager for further assistants.  
