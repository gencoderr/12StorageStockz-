# CodMWKernelInjector

change dwnld_URL to download link of your dll
